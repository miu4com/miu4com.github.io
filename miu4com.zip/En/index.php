<!DOCTYPE HTML>
<html>
<head>
<title>Lin,Yueli</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.min.css" rel="stylesheet" >
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="林约沥" />
<meta name="description" content="林约沥" />
<? include("301.in.php");?>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<!---- start-smoth-scrolling---->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
 <script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
			});
		});
	</script>
<!---End-smoth-scrolling---->
 
</head>
<body>
		<!--start-header-section-->
			<div class="header-section">
				<div class="continer">
					<img src="images/p1.png">
						<h1>lin,Yueli<span>.COM</span></h1>
							<p>我是林约沥<span>,</span>我做海产品</p>
							<a href="#contact" class="scroll top"><span class="glyphicon glyphicon-triangle-bottom" aria-hidden="true"></span></a>
				</div>
			</div>
		<!--end header-section-->
			<!--start-study-section-->
			<div class="study-section">
				<div class="container">
					<div class="study-grids">
					        <div class="col-md-6 study-grid">
					        <h3>Contact..<span>me</span></h3>
					        <div class="study1">
					          <p>
                              <i class="fa fa-mobile-phone fa-lg"></i> 13622415161<label>( Phone )</label>
				              </p>
					          <p>
                              <i class="fa fa-phone fa-lg"></i> 615161<label>( Cluster )</label>
				              </p>
					          <p>
                              <i class="fa fa-qq"></i> <a href="http://wpa.qq.com/msgrd?v=3&uin=13132014&site=qq&menu=yes" target="_new">13132014</a><label>( QQ )</label>
				              </p>
					          <p>
                              <i class="fa fa-weixin"></i> QQ13132014<label>( WeChatID )</label>
				              </p>
					          <p>
                              <i class="fa fa-envelope"></i><a href="mailto:Glinyueli@Gmail.com"> Glinyueli@Gmail.com</a><label>( Email  )</label>
				              </p>
				            </div>
				          </div>
                          <div class="col-md-6 study-grid">
					        <h3>Follow..<span>me</span></h3>
					        <div class="study1">
					          <p>
                              <i class="fa fa-facebook-official fa-lg"></i> <a href="http://www.facebook.com/glinyueli" target="_new"> Glinyueli</a><label>( FacebookID )</label>
				              </p>
							  <p>
					          <i class="fa fa-globe fa-lg"></i><a href="http://www.yulecun.com/" target="_new"> www.Yulecun.com</a><label>( Official Site )</label>
				              </p>		
							<p><i class="fa fa-weibo fa-lg"></i> <a href="http://weibo.com/444644944" target="_new"> 444644944</a><label>( WeiboID )</label></p>
							<p><i class="fa fa-tencent-weibo fa-lg"></i>  <a href="http://t.qq.com/chocolate-lyl" target="_new"> Chocolate-lyl</a><label>( TencentWeibo )</label></p>
							<p><i class="fa fa-google-plus"></i> Yueli Lin<label>( GooglePlus )</label></p>
				            </div>
				          </div>
					  <div class="col-md-6 study-grid"> 
						<h3>About..<span>me</span></h3>
						<div class="study1">
							<p><i class="fa fa-tags"></i> Chocolate<label>( NickName )</label></p>
							<p><i class="fa fa-tag fa-lg"></i> Lin,Yueli<label>( Name )</label></p>
							<p><i class="fa fa-battery-quarter"></i> 22<label>( Age )</label></p>
							<p><i class="fa fa-venus-mars"></i> Male<label>( Gender )</label></p>
 							<p><i class="fa fa-birthday-cake"></i> 28-08-1993<label>( Birthday )</label></p>
							<p><i class="fa fa-child fa-lg"></i> Rooster<label>( Animal )</label></p>
							<p><i class="fa fa-balance-scale"></i> Libra<label>( StarSign )</label></p>
							<p><i class="fa fa-plus fa-lg"></i> O<label>( Blood type )</label></p>
							<p><i class="fa fa-industry"></i> Fishing<label>( Industry )</label></p>
							<p><i class="fa fa-heartbeat"></i> Single <label>( Marital Status )</label></p>
							<p><i class="fa fa-language fa-lg"></i>  English,Chinaese,Yue Chinaese<label>( Language )</label></p>
							<p><i class="fa fa-eye fa-lg"></i> The ability is limited, effort infinite!<label>( Viewpoint )</label></p>
							<p><i class="fa fa-map-marker fa-lg"></i> No.1 Lane.6 Yulecun YangJiang Guangdong China<label>( Address )</label></p>
							</div>
						</div>
						<div class="col-md-6 study-grid">
						<h3>skills..<span>!</span></h3>
						<div class="study2">
						<h4>html</h4>
							<div class="progress">
							  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
								<span class="sr-only">40% Complete (success)</span>
							  </div>
							</div>
						<h4>css</h4>
						<div class="progress">
						  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%">
							<span class="sr-only">20% Complete</span>
						  </div>
						</div>
						<h4>js</h4>
						<div class="progress">
						  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
							<span class="sr-only">60% Complete (warning)</span>
						  </div>
						</div>
						<h4>php<h4>
						<div class="progress">
						  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
						</div>
					</div>
					<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<!--end study-section-->
			<!--start-services-section-->
			<div class="service-section" id="service">
				<div class="container">

		<div class="service-grids">
							<div class="col-md-4 service-grid">
									<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
								<h4>THE BEST DESIGN</h4>
								<span> </span>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod Lorem Ipsum passages containing of Letraset sheets</p>
							</div>
							<div class="col-md-4 service-grid">
								<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
								<h4>THE BEST SUPPORT</h4>
								<span> </span>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod Lorem Ipsum passages containing of Letraset sheets</p>
							</div>
							<div class="col-md-4 service-grid">
								<span class="glyphicon glyphicon-signal" aria-hidden="true"></span>
								<h4>THE BEST SOLUTIONS</h4>
								<span> </span>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod Lorem Ipsum passages containing of Letraset sheets</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
					<!--end services-section-->
					<!--start-social-section-->
                       		<!--end-social-section-->
							<!--start-contact-section-->
						<div class="contact-section" id="contact">
				<div class="container">
					<h3>contact</h3>
					 <div class="contact-details">
			 <form>
				 <div class="col-md-6 contact-left">
					 <input type="text" class="text" value="Name *" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name *';}">
					 <input type="text" class="text" value="Email *" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email *';}">
					 <input type="text" class="text" value="phone *" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Phone *';}">
				 </div>
				 <div class="col-md-6 contact-right">
					 <textarea  value="Message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}">Message *</textarea>
					 <input type="submit" value="Send Message"/>
				 </div>
				 <div class="clearfix"> </div>
			 </form>
			</div>		 
		</div>
	</div>
	<!--end-contact-section-->
				<!--start-map-section-->
							<!--end-map-section-->
			<!--start-footer-section-->
			<div class="footer-section">
						<div class="container">
							<div class="footer-top">
						<p>&copy; 2016 <span>Lin,Yueli</span> All rights reserved </p>
									</div>
							<script type="text/javascript">
						$(document).ready(function() {
							/*
							var defaults = {
					  			containerID: 'toTop', // fading element id
								containerHoverID: 'toTopHover', // fading element hover id
								scrollSpeed: 1200,
								easingType: 'linear' 
					 		};
							*/
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
				</div>
			</div>
	<!--end-footer-section-->


</body>
</html> 